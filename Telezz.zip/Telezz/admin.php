<?php
#code_by_Mohammed>QASIM-HHHHR >
date_default_timezone_set("Asia/Baghdad");
error_reporting(0);
if (!file_exists("ID")) {
$g = readline("admin id : ");
file_put_contents("ID", $g);
}
if (!file_exists("token")) {
$g = readline("token : ");
file_put_contents("token", $g);
}echo "Account Bot...\n";
echo "Running Bot...\n";
shell_exec("pm2 start bot.php");

echo "Done\n\n\n\n";

